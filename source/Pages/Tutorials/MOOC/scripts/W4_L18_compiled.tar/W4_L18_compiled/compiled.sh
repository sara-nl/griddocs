#!/bin/sh

# On the worker node you may have not
# execution rights
echo "setting right permissions"
chmod 755 helloexe

# run example passing as argument the shell script argument
# and redirecting its output to the helloexe.out file
echo "executing program now..."
./helloexe $1 > helloexe.out

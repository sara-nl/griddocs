#!/bin/sh

#activate debugging
set -x
#exit in case of error
set -e

echo `date`
echo `hostname`
echo $PWD

# On the worker node you may not have execution rights
echo "setting right permissions"
chmod 755 sum

# redirecting sum output to the sum.out file
echo "executing program now..."
./sum $1 $2 > sum.out

echo $PWD

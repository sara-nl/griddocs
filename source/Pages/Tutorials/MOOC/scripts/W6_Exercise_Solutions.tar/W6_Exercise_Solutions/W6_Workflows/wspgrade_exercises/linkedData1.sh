#!/bin/bash

echo -e "start $1 (`date`) hostname:`hostname`):\n------------------" > outputJob0
cat inputJob0 >> outputJob0
echo -e "\n------------------\nend $1 (`date`)" >> outputJob0


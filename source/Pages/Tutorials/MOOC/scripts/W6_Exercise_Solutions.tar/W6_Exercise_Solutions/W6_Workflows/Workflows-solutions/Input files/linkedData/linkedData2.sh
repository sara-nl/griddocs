#!/bin/bash

echo -e "start $1 (`date`) at host:`hostname`:\n------------------" > outputJob1
cat outputJob0 >> outputJob1
echo -e "\n------------------\nend $1 (`date`)" >> outputJob1

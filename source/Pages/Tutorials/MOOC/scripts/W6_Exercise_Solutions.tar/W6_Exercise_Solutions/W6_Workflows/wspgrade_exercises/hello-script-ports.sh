#!/bin/bash

echo -e "start $1 (`date`) hostname:`hostname`):\n------------------" > outputFile
cat inputFile >> outputFile
echo -e "\n------------------\nend $1 (`date`)" >> outputFile


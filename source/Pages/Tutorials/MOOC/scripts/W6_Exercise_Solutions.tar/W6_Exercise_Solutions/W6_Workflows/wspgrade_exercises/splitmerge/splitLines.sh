#!/bin/bash           

i=0
while read line           
do           
    echo -e "$line" > splitOutput_$i
    i=$(($i + 1))         
done < splitInput 

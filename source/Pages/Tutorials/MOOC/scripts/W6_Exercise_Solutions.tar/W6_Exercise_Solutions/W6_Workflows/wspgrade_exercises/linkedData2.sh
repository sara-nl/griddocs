#!/bin/bash

echo -e "start $1 (`date`) hostname:`hostname`):\n------------------" > outputJob1
cat inputJob0 >> outputJob1
echo -e "\n------------------\nend $1 (`date`)" >> outputJob1


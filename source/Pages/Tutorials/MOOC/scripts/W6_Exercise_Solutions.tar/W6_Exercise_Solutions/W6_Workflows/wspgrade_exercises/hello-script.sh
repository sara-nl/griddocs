#!/bin/bash

echo Hello $1
echo Today is `date`
echo This computer is `hostname`

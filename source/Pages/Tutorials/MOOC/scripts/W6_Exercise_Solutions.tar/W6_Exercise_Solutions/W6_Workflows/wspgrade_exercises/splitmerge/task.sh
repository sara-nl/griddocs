#!/bin/bash           
SUM=0
for i in `cat splitOutput`; do
	SUM=$((SUM += i))
done
echo "$SUM" > taskOutput

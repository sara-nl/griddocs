set -x
set -e
echo $HOSTNAME
echo $PWD
ls

echo ""
echo "Copy file from Grid Storage to the Worker Node"
srmcp -server_mode=passive srm://srm.grid.sara.nl:8443/pnfs/grid.sara.nl/data/tutor/<mooc_dir>/bbox file:///`pwd`/bbox

echo ""
echo "Run bbox executable on worker node"
chmod u+x bbox
./bbox -n 1.1

ls

echo ""
cat std.out

echo ""
echo "Copy std.out from the Worker Node to the Grid Storage"
srmcp file:///`pwd`/std.out srm://srm.grid.sara.nl:8443/pnfs/grid.sara.nl/data/tutor/<mooc_dir>/std.out

echo "Finished"

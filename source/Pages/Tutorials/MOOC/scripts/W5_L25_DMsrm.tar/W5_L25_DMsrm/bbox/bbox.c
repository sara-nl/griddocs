#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* small program that randomly fails */
int main(int argc, char *argv[])
{
    double n = -1.0;
    double failrate;
    int ch;
    FILE *out;

    while ((ch = getopt(argc, argv, "n:")) != -1) {
        switch (ch) {
        case 'n':
            n = strtod(optarg, NULL);
            break;
        }
    }

    failrate = 1.0 - sqrt(1.0/n);
 
    /* outside range [1.0, 10.0] is invalid input, so fail with exit code 1 */
    if (n < 1.0 || n > 10.0) {
        return 1;
    }

    /* random chance on segfault anyway */
    srand48(time(0));
    sleep((11.0 - n) * drand48());
    if (drand48() < failrate) {
        *(char *)(NULL) = 1;
    }

    out = fopen("std.out", "w");
    fprintf(out, "%f\n", failrate); 

    return 0;
}


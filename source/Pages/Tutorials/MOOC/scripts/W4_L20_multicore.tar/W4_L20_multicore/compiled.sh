#!/bin/sh

#activate debugging
set -x
#exit in case of error
set -e

echo `date`
echo `hostname`
echo $PWD

export OMP_NUM_THREADS=2

# On the worker node you may not have execution rights
echo "setting right permissions"
chmod 755 gridpi_reduction

# redirecting sum output to the sum.out file
echo "executing program now..."
./gridpi_reduction > gridpi_reduction.out

echo $PWD

picasclient
===========

Python client for using CouchDB as a token pool server.

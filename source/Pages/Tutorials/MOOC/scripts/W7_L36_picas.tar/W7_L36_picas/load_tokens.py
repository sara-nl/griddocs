import couchdb

def main():
    server = couchdb.Server()
    db = server['mooc']
    
    tokens = []
    for i in range(100):
        token = {
            '_id': 'token_' + str(i),
            'type': 'token',
            'lock': 0,
            'done': 0,
            'hostname': '',
            'scrub_count': 0,
            'input': {},
            'output': {}
        }
        tokens.append(token)
    db.update(tokens)

if __name__ == '__main__':
    main()

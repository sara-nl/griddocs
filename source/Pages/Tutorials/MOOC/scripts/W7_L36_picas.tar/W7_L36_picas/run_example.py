#python imports
import time

#picas imports
from picas.actors import RunActor
from picas.clients import CouchClient
from picas.iterators import BasicViewIterator
from picas.modifiers import BasicTokenModifier

class ExampleActor(RunActor):
    def __init__(self, iterator, modifier):
        self.iterator = iterator
        self.modifier = modifier
        self.client = iterator.client

    def process_token(self, key, token):
        print "-----------------------"
        print "Working on token: " + token['_id']
        for k, v in token.iteritems():
            print k, v
        print "-----------------------"
        time.sleep(3)
        token = self.modifier.close(token)
        self.client.db[token['_id']] = token

def main():
    # setup connection to db
    client = CouchClient(url="http://localhost:5984", db="mooc")
    # Create token modifier
    modifier = BasicTokenModifier()
    # Create iterator, point to the right todo view
    iterator = BasicViewIterator(client, "app1/todo", modifier)
    # Create actor
    actor = ExampleActor(iterator, modifier)
    # Start work!
    actor.run()

if __name__ == '__main__':
    main()

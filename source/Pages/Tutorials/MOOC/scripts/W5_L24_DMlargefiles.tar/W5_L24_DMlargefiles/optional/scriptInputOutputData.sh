#!/bin/sh

# Set the proper environment
export LFC_HOST=lfc.grid.sara.nl
export LCG_GFAL_INFOSYS=bdii.grid.sara.nl:2170
export LCG_CATALOG_TYPE=lfc

# Download the file from the SE to the WN where this job runs
# note that the LFN is passed as input to this script
lcg-cp --vo tutor $1 file:`pwd`/local_file

echo "########################################"
ls -la local_file
cat local_file
echo "########################################"
# type the file just downloaded
cat local_file > fileout.txt
echo "End of File---" >> fileout.txt
ls -l


# run the script which registers the file fileout.txt just created above 
# Actually upload the file to the SE
# path to the file to be registered is built as {current path}/{relative path from this script to filename}
# REPLACE CHANGEME with an (already existing) LFC directory of your choice 
lcg-cr --vo tutor -l lfn:/grid/tutor/mooc/fileout.txt  file:$PWD/fileout.txt

# greetings 
echo "All done correctly."

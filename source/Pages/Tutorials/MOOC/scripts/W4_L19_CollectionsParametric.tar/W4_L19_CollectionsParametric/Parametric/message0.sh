echo message number 0

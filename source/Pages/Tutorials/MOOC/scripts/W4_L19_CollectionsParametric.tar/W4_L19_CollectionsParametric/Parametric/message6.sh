echo message number 6

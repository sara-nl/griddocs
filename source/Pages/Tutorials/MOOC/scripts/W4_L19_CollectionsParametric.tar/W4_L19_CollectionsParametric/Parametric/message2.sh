echo message number 2

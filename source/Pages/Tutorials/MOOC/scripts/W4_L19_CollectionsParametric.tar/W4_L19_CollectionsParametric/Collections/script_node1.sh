#!/bin/sh

echo "Current date is `date`"
echo "Dumping now input files"
echo "**********************"
cat *.txt

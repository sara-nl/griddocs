#!/bin/sh

echo "Running machine is `hostname`"
ls -l
echo "Dumping now input files"
echo "**********************"
cat *.txt

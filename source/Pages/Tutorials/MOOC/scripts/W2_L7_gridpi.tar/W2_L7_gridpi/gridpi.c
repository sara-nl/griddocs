/*
 * This file, gridpi.c, is example code and part of the SURFsara MOOC 2013.
 * Copyright (c) 2013 SURFsara, all rights reserved
 * This file is Open Source under the BSD 2-Clause License: http://opensource.org/licenses/BSD-2-Clause
 */

/*
 * This example implements a serial calculation of an estimate of pi.
 * 
 * Imagine a square, 2 by 2 with its center at [0,0]: inside is equivalent to -1<x<1 and -1<y<1.
 * Imagine a circle, radius 1 with its center at [0,0]: its inside is equivalent to x*x+y*y<1.
 *
 * Use monte carlo to sample the area 0<=x<1, 0<=y<1.
 * Use the ratio of hits inside the circle / inside the square.
 * The sampled area has a surfce of 1/4 * 2*2 = 1,
 * the sampled circle has a surface of 1/4 * pi * r*r = pi / 4.
 * So, deviding the count of hits inside the circle by the total hit count
 * gives us pi/4 therefore pi = 4 * inside / total.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    long iterations = 100000000;
    long inside = 0; /* count hits inside circle */
    double x,y;
    long i;
    
    for (i = 0; i < iterations; i++) {
        /* generate a point anywhere inside the square */
        /* drand48() generates double [0.0, 1.0) */
        x = drand48();
        y = drand48();
        
        /* test if point is also inside circle */
        if (x*x + y*y < 1) {
            inside++; /* yep, count it */
        }
    }
    
    /* claculate an estimation of PI from the Monte Carlo hits */
    double estimate = 4 * (double) inside / (double) iterations;
    
    /* report */
    printf("pi: 4 * %ld / %ld = %23.20lf, diff: %23.20lf \n", inside, iterations, estimate, M_PI - estimate);
}

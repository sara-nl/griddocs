ThreadTest()
{
   for j in `(echo "A B C")`;do
	echo "I am number: "$1"_$j, and the date is:`date`"   
	sleep 10
   done
}

   for i in `(echo "1 2 3 4")`;do
   	ThreadTest $i &
   done
   wait
exit

#!/bin/bash

#activate debugging
set -x
#exit in case of error
set -e

echo `date`
/bin/hostname -f
echo $PWD
sleep 10
echo `date`

exit

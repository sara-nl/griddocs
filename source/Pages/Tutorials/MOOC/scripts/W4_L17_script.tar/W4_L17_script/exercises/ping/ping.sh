#!/bin/bash

#activate debugging
set -x
#exit in case of error
set -e

echo `date`
/bin/hostname -f
/bin/ping -c 5 $1
echo $PWD
echo `date`

exit

#!/bin/bash

#activate debugging
set -x
#exit in case of error
set -e

echo `date`
/bin/hostname -f
echo $PWD

#VM cksum result stored in cksumdataVM.out 
#WN cksum result stored in cksumdataWN.out
echo "Verify data file cksum on the Worker Node (WN):"
VM=`cat cksumdataVM.out`
export VM

WN=`cksum data`
export WN

#Compare the results
if [ "$VM" = "$WN" ]; then
   echo "Verified"
else
   echo "Not Verified"	
fi

echo `date`

exit

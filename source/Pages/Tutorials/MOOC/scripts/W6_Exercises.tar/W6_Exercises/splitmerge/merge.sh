#!/bin/bash           

cat taskOutput* > mergeOutput

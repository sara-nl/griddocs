'''
@helpdesk: SURFsara helpdesk <helpdesk@surfsara.nl>

usage: python pilot.py [picas_db_name] [picas_username] [picas_pwd]			
description:                                                                  	
	Connect to PiCaS server with [picas_username] [picas_pwd]               	
	Get the next token in todo View of [picas_db_name]			
	Fetch the token parameters, e.g. input value 					
	Run main job (master.sh) with the input argument		
	When done, return the exit code to the token
	Attach the logs to the token							
'''

#python imports
import os
import sys
import time
import couchdb

#picas imports
from picas.actors import RunActor
from picas.clients import CouchClient
from picas.iterators import BasicViewIterator
from picas.modifiers import BasicTokenModifier
from picas.executers import execute

class ExampleActor(RunActor):
    def __init__(self, iterator, modifier):
        self.iterator = iterator
        self.modifier = modifier
        self.client = iterator.client

    def process_token(self, key, token):
	# Print token information
        print "-----------------------"
        print "Working on token: " + token['_id']
        for k, v in token.iteritems():
            print k, v
        print "-----------------------"

        # Start running the main job
	# /usr/bin/time -v ./master.sh [input] [tokenid] 2> logs_[token_id].err 1> logs_[token_id].out
        command = "/usr/bin/time -v ./master.sh " + "\"" +token['input'] + "\" " + token['_id'] + " 2> logs_" + str(token['_id']) + ".err 1> logs_" + str(token['_id']) + ".out"
        print command
        
	out = execute(command,shell=True)

	# Get the job exit code in the token 
        token['exit_code'] = out[0]

	token = self.modifier.close(token)
	self.client.db[token['_id']] = token

	# Attach logs in token
	curdate=time.strftime("%d/%m/%Y_%H:%M:%S_")
	try:
           logsout = "logs_" + str(token['_id']) + ".out"
           log_handle = open(logsout, 'rb')
           self.client.db.put_attachment(token,log_handle,curdate+logsout)

           logserr = "logs_" + str(token['_id']) + ".err"
           log_handle = open(logserr, 'rb')
           self.client.db.put_attachment(token,log_handle,curdate+logserr)

	except: 
  	   pass

def main():
    # setup connection to db
    db_name = sys.argv[1]
    client = CouchClient(url="https://nosql01.grid.sara.nl:6984", db=str(sys.argv[1]), username=str(sys.argv[2]), password=str(sys.argv[3]))
    # Create token modifier
    modifier = BasicTokenModifier()
    # Create iterator, point to the right todo view
    iterator = BasicViewIterator(client, "Monitor/todo", modifier)
    # Create actor
    actor = ExampleActor(iterator, modifier)
    # Start work!
    print "Connected to the database %s sucessfully. Now starting work..." %(sys.argv[1])
    actor.run()

if __name__ == '__main__':
    main()


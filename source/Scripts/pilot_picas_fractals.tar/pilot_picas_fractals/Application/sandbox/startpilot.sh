# @helpdesk: SURFsara helpdesk <helpdesk@surfsara.nl>
#
# usage: . startpilot.sh [picas_db_name] [picas_username] [picas_pwd]	
# description: 								
#	Configure PiCaS environment for the communication with couchDB 	
#	Start the pilot job                                  		


set -x

JOBDIR=${PWD}  # the directory where the job lands

tar -xf ${JOBDIR}/picas.tar
tar -xf ${JOBDIR}/couchdb.tar

echo "Start the pilot job tasks by contacting PiCaS tokens"

# set permissions for the master script and fractals executable
chmod u+x ${JOBDIR}/master.sh
chmod u+x ${JOBDIR}/fractals
ls -l ${JOBDIR}

python ${JOBDIR}/pilot.py $1 $2 $3


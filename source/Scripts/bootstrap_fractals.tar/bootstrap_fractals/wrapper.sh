#!/bin/bash

# obtain information for the Worker Node
echo `date`
echo ${HOSTNAME}
echo ${HOME}
echo ${PWD}

# run the application
chmod u+x fractals
./fractals -o output -q 0.184 -d 2280 -m 4400

if [[ "$?" != "0" ]]; then
    echo "Problem on runtime. Exiting now..."
    exit 1
fi

# copy the output to the Grid storage (as long as grid storage is allocated for your project)
#globus-url-copy file:///`pwd`/output gsiftp://gridftp.grid.sara.nl:2811/pnfs/grid.sara.nl/data/lsgrid/homer/output

# list final files and exit
ls -allh ${PWD}
exit 0

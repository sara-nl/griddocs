#!/bin/sh
#PBS -lwalltime=00:10:00

# The following line changes the current working directory to
# the same directory where the script was submitted. Comment 
# out to set the default stdout/stderr, output location to $HOME
cd ${PBS_O_WORKDIR}

echo "TMPDIR is:" $TMPDIR
echo "PBS_O_WORKDIR is:" ${PBS_O_WORKDIR}

# run the fractals program
chmod u+x fractals
./fractals -o output -q 0.184 -d 2280 -m 4400

if [[ "$?" != "0" ]]; then
    echo "Problem on runtime. Exiting now..."
    exit 1
fi

ls -l

exit 0

#!/usr/bin/env python
import sys

sys.path.append('/opt/lcg/lib64/python2.4/site-packages/')

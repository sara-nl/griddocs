picasclient
===========

Python client using CouchDB as a token pool server.